declare const _WebSocket: any;
export { _WebSocket as WebSocket };
//# sourceMappingURL=ws-browser.d.ts.map