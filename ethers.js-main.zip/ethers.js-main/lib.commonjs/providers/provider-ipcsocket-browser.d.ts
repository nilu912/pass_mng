declare const IpcSocketProvider: undefined;
export { IpcSocketProvider };
//# sourceMappingURL=provider-ipcsocket-browser.d.ts.map