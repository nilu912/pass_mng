export {};
//# sourceMappingURL=test-providers-data.d.ts.map