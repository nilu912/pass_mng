export {};
//# sourceMappingURL=test-wordlists.d.ts.map