export declare function inspect(value: any): string;
//# sourceMappingURL=utils-debug.d.ts.map