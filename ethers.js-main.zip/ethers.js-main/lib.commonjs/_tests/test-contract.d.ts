export {};
//# sourceMappingURL=test-contract.d.ts.map