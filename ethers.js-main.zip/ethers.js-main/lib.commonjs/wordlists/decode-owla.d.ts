/**
 *  @_ignore
 */
export declare function decodeOwlA(data: string, accents: string): Array<string>;
//# sourceMappingURL=decode-owla.d.ts.map