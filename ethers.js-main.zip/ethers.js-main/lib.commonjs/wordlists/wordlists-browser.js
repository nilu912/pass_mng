"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wordlists = void 0;
const lang_en_js_1 = require("./lang-en.js");
exports.wordlists = {
    en: lang_en_js_1.LangEn.wordlist(),
};
//# sourceMappingURL=wordlists-browser.js.map