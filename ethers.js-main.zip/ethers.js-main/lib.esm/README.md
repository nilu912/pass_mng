ESM Files
=========

The contents of this folder are for using `import` in ESM
projects.


Notes
-----

The contents are generated via the `npm run build` target
using `tsc` and the `/tsconfig.esm.json` configuration.

Do not modify the files in this folder. They are deleted on `build-clean`.

To modify this `README.md`, see the `/output/post-build/lib.esm`.
