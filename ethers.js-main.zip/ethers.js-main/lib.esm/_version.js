/* Do NOT modify this file; see /src.ts/_admin/update-version.ts */
/**
 *  The current version of Ethers.
 */
export const version = "6.15.0";
//# sourceMappingURL=_version.js.map